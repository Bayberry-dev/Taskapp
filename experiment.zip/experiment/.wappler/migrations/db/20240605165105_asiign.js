
exports.up = function(knex) {
  return knex.schema
    .table('task', async function (table) {
      table.integer('asiign_to').alter().unsigned();
      table.foreign('asiign_to').references('username').inTable('user');
    })

};

exports.down = function(knex) {
  return knex.schema
    .table('task', async function (table) {
      await table.dropForeign('asiign_to');
      table.string('asiign_to', 255).alter();
    })
};
