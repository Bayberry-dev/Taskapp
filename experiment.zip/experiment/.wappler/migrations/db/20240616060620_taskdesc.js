
exports.up = function(knex) {
  return knex.schema
    .table('task', async function (table) {
      table.text('task_desc');
    })

};

exports.down = function(knex) {
  return knex.schema
    .table('task', async function (table) {
      table.dropColumn('task_desc');
    })
};
