
exports.up = function(knex) {
  return knex.schema
    .createTable('task_progress_attachment', async function (table) {
      table.increments('attachment_id');
      table.string('attachment_desc');
      table.string('attachment_file');
      table.string('attachment_type');
      table.string('attachment_size');
      table.integer('progress_id').unsigned();
      table.foreign('progress_id').references('progress_id').inTable('task_progress').onUpdate('CASCADE').onDelete('CASCADE');
      table.string('uploaded_by');
      table.string('uploaded_dt');
    })

};

exports.down = function(knex) {
  return knex.schema
    .dropTable('task_progress_attachment')
};
