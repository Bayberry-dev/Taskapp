
exports.up = function(knex) {
  return knex.schema
    .dropTable('task')

};

exports.down = function(knex) {
  return knex.schema
    .createTable('task', async function (table) {
      table.string('task_id', 36).primary().unique().defaultTo(null);
      table.text('task_name');
      table.string('priority', 255);
      table.string('category', 255);
      table.string('assign_to', 255);
      table.string('created_by', 255);
      table.string('created_dt', 255);
      table.string('status', 255);
      table.string('rank', 255);
    })
};
