
exports.up = function(knex) {
  return knex.schema
    .createTable('cat', async function (table) {
      table.increments('cat_id');
      table.string('cat_name');
      table.string('cat_color');
    })

};

exports.down = function(knex) {
  return knex.schema
    .dropTable('cat')
};
