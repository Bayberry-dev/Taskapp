
exports.up = function(knex) {
  return knex.schema
    .createTable('task_progress_comment', async function (table) {
      table.increments('comment_id');
      table.string('comment_text');
      table.string('comment_by');
      table.string('comment_dt');
      table.integer('progress_id').unsigned();
      table.foreign('progress_id').references('progress_id').inTable('task_progress').onUpdate('CASCADE').onDelete('CASCADE');
    })

};

exports.down = function(knex) {
  return knex.schema
    .dropTable('task_progress_comment')
};
