
exports.up = function(knex) {
  return knex.schema
    .createTable('task', async function (table) {
      table.increments('task_id');
      table.text('task_name');
      table.string('category');
      table.string('status');
      table.string('rank');
      table.string('asiign_to');
      table.string('created_by');
      table.string('created_dt');
    })

};

exports.down = function(knex) {
  return knex.schema
    .dropTable('task')
};
