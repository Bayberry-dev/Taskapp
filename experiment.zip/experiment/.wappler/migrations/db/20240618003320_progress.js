
exports.up = function(knex) {
  return knex.schema
    .createTable('task_progress', async function (table) {
      table.increments('progress_id');
      table.string('progress_report');
      table.string('created_by');
      table.string('created_dt');
      table.integer('task_id').unsigned();
      table.foreign('task_id').references('task_id').inTable('task').onUpdate('CASCADE').onDelete('CASCADE');
    })

};

exports.down = function(knex) {
  return knex.schema
    .dropTable('task_progress')
};
