
exports.up = function(knex) {
  return knex.schema
    .raw(knex.client.constructor.name.startsWith('Client_PG') ? 'CREATE EXTENSION IF NOT EXISTS "uuid-ossp"' : 'SELECT 1')
    .createTable('task', async function (table) {
      table.uuid('task_id').primary().defaultTo(knex.client.constructor.name.startsWith('Client_PG') ? knex.raw('uuid_generate_v4()')
              : (knex.client.constructor.name.includes('MSSQL') ? knex.raw('NEWID()')
                : (knex.client.constructor.name.includes('MySQL') ? knex.raw('(UUID())') : null)));
      table.text('task_name');
      table.string('priority');
      table.string('category');
      table.string('assign_to');
      table.string('created_by');
      table.string('created_dt');
      table.string('status');
      table.string('rank');
    })

};

exports.down = function(knex) {
  return knex.schema
    .dropTable('task')
};
