
exports.up = function(knex) {
  return knex.schema
    .dropTable('category')

};

exports.down = function(knex) {
  return knex.schema
    .createTable('category', async function (table) {
      table.string('cat_id', 36).primary().unique().defaultTo(null);
      table.string('cat_name', 255);
    })
};
