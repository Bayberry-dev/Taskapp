
exports.up = function(knex) {
  return knex.schema
    .createTable('dept', async function (table) {
      table.increments('dept_id');
      table.string('dept_name');
      table.string('dept_color');
    })

};

exports.down = function(knex) {
  return knex.schema
    .dropTable('dept')
};
