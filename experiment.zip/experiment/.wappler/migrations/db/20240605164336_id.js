
exports.up = function(knex) {
  return knex.schema
    .dropTable('user')

};

exports.down = function(knex) {
  return knex.schema
    .createTable('user', async function (table) {
      table.string('user_id', 36).primary().unique().defaultTo(null);
      table.string('username', 255);
    })
};
