
exports.up = function(knex) {
  return knex.schema
    .table('task_progress', async function (table) {
      table.integer('like');
    })

};

exports.down = function(knex) {
  return knex.schema
    .table('task_progress', async function (table) {
      table.dropColumn('like');
    })
};
