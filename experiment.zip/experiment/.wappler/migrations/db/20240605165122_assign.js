
exports.up = function(knex) {
  return knex.schema
    .table('task', async function (table) {
      table.renameColumn('asiign_to', 'assign_to');
    })

};

exports.down = function(knex) {
  return knex.schema
    .table('task', async function (table) {
      table.renameColumn('assign_to', 'asiign_to');
    })
};
