dmx.config({
  "dashboard": {
    "repeat_progress": {
      "meta": [
        {
          "type": "number",
          "name": "progress_id"
        },
        {
          "type": "text",
          "name": "progress_report"
        },
        {
          "type": "text",
          "name": "created_by"
        },
        {
          "type": "text",
          "name": "created_dt"
        },
        {
          "type": "number",
          "name": "task_id"
        },
        {
          "name": "attachment",
          "type": "array",
          "sub": [
            {
              "type": "number",
              "name": "attachment_id"
            },
            {
              "type": "text",
              "name": "attachment_desc"
            },
            {
              "type": "text",
              "name": "attachment_file"
            },
            {
              "type": "text",
              "name": "attachment_type"
            },
            {
              "type": "text",
              "name": "attachment_size"
            },
            {
              "type": "number",
              "name": "progress_id"
            },
            {
              "type": "text",
              "name": "uploaded_by"
            },
            {
              "type": "text",
              "name": "uploaded_dt"
            }
          ]
        },
        {
          "name": "comment",
          "type": "array",
          "sub": [
            {
              "type": "number",
              "name": "comment_id"
            },
            {
              "type": "text",
              "name": "comment_text"
            },
            {
              "type": "text",
              "name": "comment_by"
            },
            {
              "type": "text",
              "name": "comment_dt"
            },
            {
              "type": "number",
              "name": "progress_id"
            }
          ]
        }
      ],
      "outputType": "array"
    },
    "repeat_link": {
      "meta": [
        {
          "type": "number",
          "name": "attachment_id"
        },
        {
          "type": "text",
          "name": "attachment_desc"
        },
        {
          "type": "text",
          "name": "attachment_file"
        },
        {
          "type": "text",
          "name": "attachment_type"
        },
        {
          "type": "text",
          "name": "attachment_size"
        },
        {
          "type": "number",
          "name": "progress_id"
        },
        {
          "type": "text",
          "name": "uploaded_by"
        },
        {
          "type": "text",
          "name": "uploaded_dt"
        }
      ],
      "outputType": "array"
    },
    "repeat_comment": {
      "meta": [
        {
          "type": "number",
          "name": "comment_id"
        },
        {
          "type": "text",
          "name": "comment_text"
        },
        {
          "type": "text",
          "name": "comment_by"
        },
        {
          "type": "text",
          "name": "comment_dt"
        },
        {
          "type": "number",
          "name": "progress_id"
        }
      ],
      "outputType": "array"
    }
  }
});
